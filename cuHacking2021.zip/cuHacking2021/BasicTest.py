import cv2
import numpy as np
from pyzbar.pyzbar import decode

def loadFile(filename):
  name_file = []
  with open(filename, "r") as f:
    for line in f:
      name_file.append([str(val) for val in line.strip().split(",")])
  return name_file


def main():
  # Test QR Code
  img = cv2.imread('MateiQR.PNG')
  cap = cv2.VideoCapture(0)
  cap.set(3, 640)
  cap.set(4, 480)

  while True:
    success, img = cap.read()
    for barcode in decode(img):
      #print(barcode.data)
      myData = barcode.data.decode('utf-8')
      #print(myData)
      pts = np.array([barcode.polygon], np.int32)
      pts = pts.reshape((-1, 1, 2))
      cv2.polylines(img, [pts], True, (0, 255, 0), 5)

      found_name = barcode.data.decode('utf-8')  # add the found name
      filename = "Names.txt"
      names = loadFile(filename)
      #print(names)
      i = 0
      for name in names:
        #print(name[0])
        if name[0] == found_name:
          #print(name[0] + 'found')
          names[i][0] = name[0] + " present"
        i = i + 1
        #print(names)
      fileOut = open(filename, "w")
      for name in names:
        fileOut.write(name[0] + "\n")
      fileOut.close()

    cv2.imshow('Result', img)
    cv2.waitKey(1)


# Guard for main function - do NOT remove or change
if __name__ == "__main__":
  main()



